"use strict";
$(document).ready(function() {

	var elemprimary = document.querySelector('.js-inverse');
	var switchery = new Switchery(elemprimary, { color: '#34495e', jackColor: '#fff', size:'small' });

	var elemprimary = document.querySelector('.js-inverse2');
	var switchery = new Switchery(elemprimary, { color: '#34495e', jackColor: '#fff', size:'small' });

});